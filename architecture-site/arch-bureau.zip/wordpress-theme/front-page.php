<?php
/**
 * Шаблон главной страницы
 */
get_header();
?>

<div class="home">
    <!-- Hero Section -->
    <section class="hero" id="hero">
        <div class="hero-background">
            <div class="hero-image"></div>
            <div class="hero-overlay"></div>
        </div>
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1 class="hero-title">
                        АРХИТЕКТУРА
                        <br>
                        <span class="accent">БЕЗ КОМПРОМИССОВ</span>
                    </h1>
                    <p class="hero-description">
                        Создаем пространства, которые формируют будущее.
                        Брутализм как философия дизайна. Чистота форм.
                        Функциональность превыше всего.
                    </p>
                    <div class="hero-actions">
                        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary">
                            НАЧАТЬ ПРОЕКТ
                        </a>
                        <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-secondary">
                            СМОТРЕТЬ РАБОТЫ
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-scroll-indicator">
            <span>СКРОЛЛ</span>
            <div class="scroll-arrow"></div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number" data-value="150">0</div>
                    <div class="stat-label">ПРОЕКТОВ</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" data-value="25">0</div>
                    <div class="stat-label">ЛЕТ ОПЫТА</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" data-value="50">0</div>
                    <div class="stat-label">НАГРАД</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" data-value="30">0</div>
                    <div class="stat-label">СТРАН</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <?php
    $projects_query = new WP_Query(array(
        'post_type'      => 'project',
        'posts_per_page' => 3,
        'post_status'    => 'publish',
    ));
    
    // Если нет кастомного типа записей "project", используем обычные посты
    if (!$projects_query->have_posts()) {
        $projects_query = new WP_Query(array(
            'post_type'      => 'post',
            'posts_per_page' => 3,
            'post_status'    => 'publish',
            'category_name'  => 'projects',
        ));
    }
    ?>
    
    <?php if ($projects_query->have_posts()) : ?>
    <section class="projects-section section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">ПРОЕКТЫ</h2>
                <p class="section-subtitle">Выборочный портфель работ</p>
            </div>
            <div class="projects-grid">
                <?php while ($projects_query->have_posts()) : $projects_query->the_post(); ?>
                    <div class="project-item">
                        <div class="project-image-wrapper">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="project-image" style="background-image: url('<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'arch-bureau-project')); ?>');"></div>
                            <?php else : ?>
                                <div class="project-image" style="background-image: url('https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&h=600&fit=crop');"></div>
                            <?php endif; ?>
                            <div class="project-overlay">
                                <div class="project-info">
                                    <?php
                                    $categories = get_the_category();
                                    if (!empty($categories)) :
                                    ?>
                                        <span class="project-category"><?php echo esc_html(strtoupper($categories[0]->name)); ?></span>
                                    <?php endif; ?>
                                    <h3 class="project-title"><?php the_title(); ?></h3>
                                    <p class="project-location"><?php echo get_the_date('Y'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Services Section -->
    <section class="services-section section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">УСЛУГИ</h2>
                <p class="section-subtitle">Полный спектр архитектурных решений</p>
            </div>
            <div class="services-grid">
                <div class="service-item">
                    <div class="service-number">01</div>
                    <h3 class="service-title">ЖИЛАЯ АРХИТЕКТУРА</h3>
                    <p class="service-description">Проектирование жилых комплексов, частных домов и апартаментов.</p>
                </div>
                <div class="service-item">
                    <div class="service-number">02</div>
                    <h3 class="service-title">КОММЕРЧЕСКАЯ АРХИТЕКТУРА</h3>
                    <p class="service-description">Офисные здания, торговые центры, бизнес-центры.</p>
                </div>
                <div class="service-item">
                    <div class="service-number">03</div>
                    <h3 class="service-title">КУЛЬТУРНЫЕ ОБЪЕКТЫ</h3>
                    <p class="service-description">Музеи, театры, библиотеки, культурные центры.</p>
                </div>
                <div class="service-item">
                    <div class="service-number">04</div>
                    <h3 class="service-title">ГРАДОСТРОИТЕЛЬСТВО</h3>
                    <p class="service-description">Планирование городских пространств и общественных зон.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section class="process-section section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">ПРОЦЕСС РАБОТЫ</h2>
                <p class="section-subtitle">От концепции до реализации</p>
            </div>
            <div class="process-grid">
                <div class="process-card">
                    <div class="process-card-number">01</div>
                    <div class="process-card-content">
                        <h3 class="process-card-title">ИССЛЕДОВАНИЕ</h3>
                        <p class="process-card-description">Анализ участка, требований, контекста</p>
                    </div>
                    <div class="process-card-arrow">→</div>
                </div>
                <div class="process-card">
                    <div class="process-card-number">02</div>
                    <div class="process-card-content">
                        <h3 class="process-card-title">КОНЦЕПЦИЯ</h3>
                        <p class="process-card-description">Разработка архитектурной концепции</p>
                    </div>
                    <div class="process-card-arrow">→</div>
                </div>
                <div class="process-card">
                    <div class="process-card-number">03</div>
                    <div class="process-card-content">
                        <h3 class="process-card-title">ПРОЕКТИРОВАНИЕ</h3>
                        <p class="process-card-description">Детальная проработка проекта</p>
                    </div>
                    <div class="process-card-arrow">→</div>
                </div>
                <div class="process-card">
                    <div class="process-card-number">04</div>
                    <div class="process-card-content">
                        <h3 class="process-card-title">РАЗРАБОТКА</h3>
                        <p class="process-card-description">Техническая документация и согласования</p>
                    </div>
                    <div class="process-card-arrow">→</div>
                </div>
                <div class="process-card">
                    <div class="process-card-number">05</div>
                    <div class="process-card-content">
                        <h3 class="process-card-title">РЕАЛИЗАЦИЯ</h3>
                        <p class="process-card-description">Авторский надзор и реализация проекта</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Philosophy Section -->
    <section class="philosophy-section section">
        <div class="container">
            <div class="philosophy-content">
                <div class="philosophy-text">
                    <h2 class="philosophy-title">ФИЛОСОФИЯ</h2>
                    <div class="philosophy-description">
                        <p>
                            Мы верим в силу простоты. Каждая линия имеет значение.
                            Каждая форма выполняет функцию. Брутализм — это не грубость,
                            это честность материала и конструкции.
                        </p>
                        <p>
                            Наш подход основан на трех принципах: функциональность,
                            долговечность и эстетическая чистота. Мы создаем архитектуру,
                            которая стоит веками.
                        </p>
                    </div>
                </div>
                <div class="philosophy-visual brutal-grid"></div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section section">
        <div class="container">
            <div class="cta-content">
                <h2 class="cta-title">ГОТОВЫ НАЧАТЬ ПРОЕКТ?</h2>
                <p class="cta-description">
                    Свяжитесь с нами сегодня и обсудим ваши идеи.
                    Создадим пространство, которое формирует будущее.
                </p>
                <div class="cta-actions">
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary btn-large">
                        СВЯЗАТЬСЯ С НАМИ
                    </a>
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-secondary btn-large">
                        СМОТРЕТЬ РАБОТЫ
                    </a>
                </div>
            </div>
        </div>
    </section>
</div>

<?php
get_footer();
?>

