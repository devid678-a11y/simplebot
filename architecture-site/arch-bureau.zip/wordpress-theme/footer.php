    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="footer-title">ARCH BUREAU</h3>
                    <p class="footer-description">
                        Архитектурное бюро, создающее пространства будущего.
                        Брутализм. Функциональность. Вневременность.
                    </p>
                </div>

                <div class="footer-section">
                    <h4 class="footer-heading">НАВИГАЦИЯ</h4>
                    <nav class="footer-nav">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'footer',
                            'container'      => false,
                            'menu_class'     => 'footer-nav-menu',
                            'fallback_cb'    => 'arch_bureau_footer_fallback_menu',
                            'items_wrap'     => '<ul class="%2$s">%3$s</ul>',
                        ));
                        ?>
                    </nav>
                </div>

                <div class="footer-section">
                    <h4 class="footer-heading">КОНТАКТЫ</h4>
                    <div class="footer-contact">
                        <a href="mailto:info@archbureau.ru" class="footer-link">
                            INFO@ARCHBUREAU.RU
                        </a>
                        <a href="tel:+74951234567" class="footer-link">
                            +7 (495) 123-45-67
                        </a>
                        <p class="footer-address">
                            МОСКВА, УЛ. АРХИТЕКТОРОВ, 15
                        </p>
                    </div>
                </div>

                <div class="footer-section">
                    <h4 class="footer-heading">СОЦИАЛЬНЫЕ СЕТИ</h4>
                    <div class="footer-social">
                        <a href="#" class="footer-social-link">INSTAGRAM</a>
                        <a href="#" class="footer-social-link">FACEBOOK</a>
                        <a href="#" class="footer-social-link">LINKEDIN</a>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <p class="footer-copyright">
                    © <?php echo date('Y'); ?> ARCH BUREAU. ВСЕ ПРАВА ЗАЩИЩЕНЫ.
                </p>
                <p class="footer-design">
                    ДИЗАЙН В СТИЛЕ БРУТАЛИЗМ
                </p>
            </div>
        </div>
    </footer>

    <!-- Scroll to Top Button -->
    <button class="scroll-to-top" id="scrollToTop" aria-label="Scroll to top">
        ↑
    </button>
</div>

<?php wp_footer(); ?>
</body>
</html>

<?php
/**
 * Функция для fallback меню в header
 */
function arch_bureau_fallback_menu() {
    echo '<ul class="nav-menu">';
    echo '<li><a href="' . esc_url(home_url('/')) . '" class="nav-link">ГЛАВНАЯ</a></li>';
    echo '<li><a href="' . esc_url(home_url('/blog')) . '" class="nav-link">БЛОГ</a></li>';
    echo '<li><a href="' . esc_url(home_url('/contact')) . '" class="nav-link">КОНТАКТЫ</a></li>';
    echo '</ul>';
}

/**
 * Функция для fallback меню в footer
 */
function arch_bureau_footer_fallback_menu() {
    echo '<ul class="footer-nav-menu">';
    echo '<li><a href="' . esc_url(home_url('/')) . '" class="footer-link">ГЛАВНАЯ</a></li>';
    echo '<li><a href="' . esc_url(home_url('/blog')) . '" class="footer-link">БЛОГ</a></li>';
    echo '<li><a href="' . esc_url(home_url('/contact')) . '" class="footer-link">КОНТАКТЫ</a></li>';
    echo '</ul>';
}
?>

